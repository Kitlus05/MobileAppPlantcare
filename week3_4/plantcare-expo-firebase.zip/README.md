# PlantCare - Expo SDK 57

Bản chuyển đổi từ Flutter UI sang React Native + Expo + JavaScript + JSON. Project này đã được nâng lên **Expo SDK 57**. Theo tài liệu Expo, SDK 57 dùng React Native 0.86, React 19.2.3 và yêu cầu Node.js tối thiểu 22.13.x.

## Chạy bằng Expo Go

1. Cài Node.js 22.13.x hoặc mới hơn thuộc dòng được Expo hỗ trợ.
2. Mở Terminal trong thư mục project.
3. Cài dependency:

```powershell
npm install
```

4. Kiểm tra dependency Expo:

```powershell
npx expo-doctor
```

5. Chạy project:

```powershell
npx expo start
```

6. Mở Expo Go trên điện thoại và chọn **Scan QR**. Điện thoại và máy tính nên cùng Wi-Fi. Nếu LAN không kết nối được:

```powershell
npx expo start --tunnel
```

## Dữ liệu

Dữ liệu cây nằm trong `data/plants.json`. UI hiện là demo và chưa kết nối cảm biến/backend.

## Nếu Expo báo lệch dependency

Chạy:

```powershell
npx expo install --fix
```

Sau đó chạy lại `npx expo start`. Không nên dùng `npm audit fix --force` cho project Expo vì có thể nâng dependency lớn ngoài phạm vi SDK.
