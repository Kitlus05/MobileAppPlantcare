import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, FlatList, StyleSheet, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ref, onValue } from 'firebase/database';
import { PageTitle, PlantCard } from '../components/Common';
import { db } from '../firebaseConfig';
import { useAuth } from '../contexts/AuthContext';
import { C } from '../styles';

export default function PlantsScreen({ navigation }) {
  const { user } = useAuth();
  const [q, setQ] = useState('');
  const [plants, setPlants] = useState([]);
  const [loading, setLoading] = useState(true);

  // plants có rules mở (".read": true) nên đọc thẳng cả node rồi lọc theo owner_uid
  useEffect(() => {
    if (!user) return;
    return onValue(ref(db, 'plants'), (snap) => {
      const data = snap.val() || {};
      const list = Object.entries(data)
        .filter(([, p]) => p.owner_uid === user.uid)
        .map(([id, p]) => ({
          id,
          name: p.name,
          type: p.name,
          moisture: p.current_data?.soil_moisture ?? 0,
          status: p.current_data?.status || '...',
        }));
      setPlants(list);
      setLoading(false);
    });
  }, [user]);

  const list = plants.filter((p) => (p.name + ' ' + p.type).toLowerCase().includes(q.toLowerCase()));

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <PageTitle title="Cây trồng" subtitle="Quản lý các cây đang chăm sóc" />
      <View style={s.search}>
        <Ionicons name="search" size={21} color={C.gray} />
        <TextInput value={q} onChangeText={setQ} placeholder="Tìm kiếm cây..." style={{ flex: 1 }} />
      </View>
      {loading ? (
        <ActivityIndicator color={C.green} style={{ marginTop: 30 }} />
      ) : (
        <FlatList
          data={list}
          keyExtractor={(x) => x.id}
          contentContainerStyle={{ padding: 20, paddingTop: 4 }}
          ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
          ListEmptyComponent={<Text style={{ textAlign: 'center', color: C.gray, marginTop: 20 }}>Chưa có cây nào.</Text>}
          renderItem={({ item }) => (
            <PlantCard plant={item} onPress={() => navigation.navigate('PlantDetail', { plantId: item.id })} />
          )}
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  search: { marginHorizontal: 20, marginBottom: 4, padding: 3, paddingHorizontal: 14, height: 52, borderRadius: 16, backgroundColor: '#fff', flexDirection: 'row', alignItems: 'center', gap: 10 },
});
