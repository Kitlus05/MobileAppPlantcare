import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ref, onValue } from 'firebase/database';
import { PageTitle, PlantCard, SensorCard } from '../components/Common';
import { db } from '../firebaseConfig';
import { useAuth } from '../contexts/AuthContext';
import { C } from '../styles';

export default function HomeScreen({ navigation }) {
  const { user } = useAuth();
  const [userName, setUserName] = useState('User');
  const [plantId, setPlantId] = useState(null);
  const [plant, setPlant] = useState(null);

  // Lấy tên user + id cây đầu tiên của họ từ node users/{uid}
  useEffect(() => {
    if (!user) return;
    return onValue(ref(db, `users/${user.uid}`), (snap) => {
      const data = snap.val();
      if (!data) return;
      setUserName(data.name || 'User');
      const ids = data.plant_ids || [];
      setPlantId(ids[0] || null);
    });
  }, [user]);

  // Lắng nghe realtime dữ liệu cây đó
  useEffect(() => {
    if (!plantId) return;
    return onValue(ref(db, `plants/${plantId}`), (snap) => setPlant(snap.val()));
  }, [plantId]);

  if (!plantId || !plant) {
    return (
      <View style={s.center}>
        <ActivityIndicator color={C.green} />
        {!plantId && <Text style={{ color: C.gray, marginTop: 10 }}>Bạn chưa có cây nào.</Text>}
      </View>
    );
  }

  const cd = plant.current_data || {};
  const cardPlant = {
    id: plantId,
    name: plant.name,
    type: plant.name,
    moisture: cd.soil_moisture ?? 0,
    status: cd.status || '...',
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.bg }} contentContainerStyle={{ paddingBottom: 25 }}>
      <View style={s.header}>
        <View style={s.avatar}>
          <Ionicons name="person" size={21} color={C.green} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={s.hello}>Xin chào, {userName}!</Text>
          <Text style={s.greet}>Chúc cây của bạn luôn khỏe 🌱</Text>
        </View>
        <Ionicons name="notifications-outline" size={25} color="#303530" onPress={() => navigation.navigate('Notifications')} />
      </View>

      <PageTitle title="Cây của tôi" />
      <View style={{ paddingHorizontal: 20 }}>
        <PlantCard
          plant={cardPlant}
          onPress={() => navigation.navigate('Plants', { screen: 'PlantDetail', params: { plantId } })}
        />
      </View>

      <PageTitle title="Thông tin nhanh" />
      <View style={s.grid}>
        <SensorCard icon="water" title="Độ ẩm đất" value={`${cd.soil_moisture ?? '--'}%`} color={C.blue} />
        <SensorCard icon="thermo" title="Nhiệt độ" value={`${cd.temperature ?? '--'}°C`} color={C.orange} />
        <SensorCard icon="air" title="Độ ẩm không khí" value={`${cd.humidity ?? '--'}%`} color={C.blue} />
        <SensorCard icon="sun" title="Ánh sáng" value={`${cd.light ?? '--'}%`} color={C.orange} />
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: C.bg },
  header: { padding: 16, paddingHorizontal: 20, flexDirection: 'row', alignItems: 'center', gap: 12 },
  avatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: C.paleGreen, alignItems: 'center', justifyContent: 'center' },
  hello: { fontSize: 18, fontWeight: '800' },
  greet: { color: C.gray },
  grid: { paddingHorizontal: 20, flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
});
