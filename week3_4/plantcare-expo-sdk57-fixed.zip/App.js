import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import { View } from 'react-native';
import HomeScreen from './screens/HomeScreen';
import PlantsScreen from './screens/PlantsScreen';
import PlantDetailScreen from './screens/PlantDetailScreen';
import HistoryScreen from './screens/HistoryScreen';
import NotificationsScreen from './screens/NotificationsScreen';
import SettingsScreen from './screens/SettingsScreen';

const Stack=createNativeStackNavigator(), Tab=createBottomTabNavigator();
function PlantStack(){return <Stack.Navigator screenOptions={{headerShadowVisible:false,headerTintColor:'#0D6931',headerTitleStyle:{fontWeight:'700'}}}><Stack.Screen name="Plants" component={PlantsScreen} options={{headerShown:false}}/><Stack.Screen name="PlantDetail" component={PlantDetailScreen} options={{title:'Tomato Plant'}}/></Stack.Navigator>}
function Tabs(){return <Tab.Navigator screenOptions={({route})=>({headerShown:false,tabBarActiveTintColor:'#16833F',tabBarInactiveTintColor:'#7B817B',tabBarStyle:{height:66,paddingBottom:8,paddingTop:6,backgroundColor:'#fff',borderTopWidth:0},tabBarLabelStyle:{fontSize:11,fontWeight:'600'},tabBarIcon:({focused,color,size})=>{const map={Home:focused?'home':'home-outline',Plants:focused?'leaf':'leaf-outline',History:'history',Notifications:focused?'notifications':'notifications-outline',Settings:focused?'settings':'settings-outline'}; return <Ionicons name={map[route.name]} size={size} color={color}/>}})}><Tab.Screen name="Home" component={HomeScreen} options={{title:'Trang chủ'}}/><Tab.Screen name="Plants" component={PlantStack} options={{title:'Cây trồng'}}/><Tab.Screen name="History" component={HistoryScreen} options={{title:'Lịch sử'}}/><Tab.Screen name="Notifications" component={NotificationsScreen} options={{title:'Thông báo'}}/><Tab.Screen name="Settings" component={SettingsScreen} options={{title:'Cài đặt'}}/></Tab.Navigator>}
export default function App(){return <><StatusBar style="dark"/><NavigationContainer><Tabs/></NavigationContainer></>}
